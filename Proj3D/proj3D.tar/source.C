#include <source.h>
Source::Source(void){};

Image* Source::GetOutput(){
	return &image;
}
