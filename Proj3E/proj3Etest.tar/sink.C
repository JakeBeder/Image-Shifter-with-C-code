#include <sink.h>

Sink::Sink(void) {};

void Sink::SetInput(Image* Input1){
	input = Input1;
};

void Sink::SetInput2(Image* Input2){
	input2 = Input2;
};
